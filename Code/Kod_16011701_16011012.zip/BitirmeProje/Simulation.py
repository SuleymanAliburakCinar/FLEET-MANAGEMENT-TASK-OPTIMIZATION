import sys
import time
from tkinter import Tk, messagebox
import pygame
from Agv import Agv
from Button import Button
from Spot import Spot
from Target import Target
from queue import PriorityQueue
from collections import deque

from InputBox import InputBox

WIDTH = 720
HEIGHT = 1280

pygame.init()

top_left_x = (WIDTH - 500) // 2
top_left_y = (HEIGHT - 500) // 2

pygame.display.set_caption("Fleet Management Task Optimization")

RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
ORANGE = (255, 180, 0)
TURQUOISE = (64, 224, 208)
YELLOW = (255, 255, 0)
GREY = (80, 80, 80)
GREY2 = (140, 140, 140)
PURPLE = (128, 0, 128)
# The button can be styled in a manner similar to CSS.
BUTTON_STYLE = {
    "hover_color": BLUE,
    "clicked_color": GREEN,
    "clicked_font_color": BLACK,
    "hover_font_color": ORANGE,
}
BUTTON_STYLE1 = {
    "hover_color": BLUE,
    "clicked_color": GREEN,
    "clicked_font_color": BLACK,
    "hover_font_color": ORANGE,
}


class Simulation:
    def __init__(self, rows, width):
        pygame.init()
        pygame.display.set_caption("Fleet Management Task Optimization")
        self.win = pygame.display.set_mode((HEIGHT, WIDTH))

        self.file_dialog = None
        self.InputBox = InputBox(920, top_left_x, 330, 30)
        self.InputBoxAgv = InputBox(30, top_left_x, 200, 28)

        self.max_image_display_dimensions = (400, 400)
        self.display_loaded_image = None

        self.command_list = []

        self.rows = rows
        self.width = width
        self.grid = []
        self.aGrid = []
        self.aGrid2 = []
        self.dGrid = []
        self.dGrid2 = []
        self.AGVs = []
        self.targets = []
        self.obstacle = []
        self.medium = []
        self.hard = []
        self.mod = 2

        self.myfont = pygame.font.SysFont("monospace", 15)
        self.label = self.myfont.render("A* Algorithm", 1, (0, 0, 0))
        self.label2 = self.myfont.render("Dijkstra Algorithm", 1, (0, 0, 0))

        message = "Button"
        self.button = Button(
            (1050, top_left_x + 38, 100, 20), RED, self.take_command, text=message, **BUTTON_STYLE
        )
        message = "Robot"
        self.button2 = Button(
            (260, top_left_x + 4, 100, 20), RED, self.take_agv, text=message, **BUTTON_STYLE1
        )

    def duplicate(self):
        for row in self.grid:
            for spot in row:
                self.aGrid[spot.row][spot.col].color = spot.color
        for row in self.grid:
            for spot in row:
                self.dGrid[spot.row][spot.col].color = spot.color
        for row in self.grid:
            for spot in row:
                self.aGrid2[spot.row][spot.col].color = spot.color
        for row in self.grid:
            for spot in row:
                self.dGrid2[spot.row][spot.col].color = spot.color

    def reset_robot(self, v):
        v.secondPath = []
        v.firstPath = []
        v.flag = 0

    def is_robot(self, cmd):
        for v in self.AGVs:
            if v.get_pos() == cmd:
                return v
        return False

    def is_target(self, cmd):
        for t in self.targets:
            if t.get_pos() == cmd:
                return t
        return False

    def check_syntax(self, string):  # Görev eklemek girilen inputun Syntaxını kontrol eden kod
        splitString = string.split()
        try:
            if len(splitString) % 5 == 0:
                i = 0
                for tmp in splitString:
                    if i % 5 == 4 and not int(tmp) in (0, 1):
                        Tk().wm_withdraw()
                        messagebox.showinfo("Wrong Syntax", "Wrong value")
                        return False
                    elif 24 < int(tmp) or int(tmp) < 0:
                        Tk().wm_withdraw()
                        messagebox.showinfo("Wrong Syntax", "Wrong value")
                        return False
                    i += 1
            else:
                Tk().wm_withdraw()
                messagebox.showinfo("Wrong Syntax", "Miss input")
                return False
        except:
            Tk().wm_withdraw()
            messagebox.showinfo("Wrong Syntax", "Wrong value")
            return False
        i = 4
        tupleList = []
        tuple1 = (0, 0)
        tuple2 = (0, 0)
        while i <= len(splitString):
            tuple1 = int(splitString[i - 4]), int(splitString[i - 3])
            tuple2 = int(splitString[i - 2]), int(splitString[i - 1])
            tuple3 = int(splitString[i])
            tupleList.append([tuple1, tuple2, tuple3])
            # tupleList.append(tuple2)
            # tupleList.append(tuple3)
            i += 5
        if not self.check_grid(tuple1):  # or not self.check_grid(tuple2):
            return False
        if not self.check_grid2(tuple2):  # or not self.check_grid(tuple2):
            return False
        return tupleList

    def check_input(self, string):  # Robot eklemek girilen inputun Syntaxını kontrol eden kod
        splitString = string.split()
        try:
            if len(splitString) % 2 == 0:
                for tmp in splitString:
                    if 24 < int(tmp) or int(tmp) < 0:
                        Tk().wm_withdraw()
                        messagebox.showinfo("Wrong Syntax", "Wrong value")
                        return False
            else:
                Tk().wm_withdraw()
                messagebox.showinfo("Wrong Syntax", "Miss input")
                return False
        except:
            Tk().wm_withdraw()
            messagebox.showinfo("Wrong Syntax", "Wrong value")
            return False
        tmp = int(splitString[0]), int(splitString[1])
        if not self.check_grid(tmp):  # or not self.check_grid(tuple2):
            return False
        return splitString

    def do_command(self):  # Görev listesinde bulunan görevleri çalıştıran kod
        if len(self.targets) > 0:
            check = 0
            for a in self.AGVs:
                if a.flag == 0:
                    check = 1
            if check != 1:
                return False
            for t in self.targets:
                if not t.flag:
                    self.duplicate()
                    self.aStar(t, t.destination)
        # if len(self.command_list) > 0 and len(self.command_list[0]) > 0:
        #     check = 0
        #     for a in self.AGVs:
        #         if a.flag == 0:
        #             check = 1
        #     if check != 1:
        #         return False
        #     tmp = self.command_list[0].pop(0)
        #     spot = self.grid[tmp[1][0]][tmp[1][1]]
        #     self.createTarget(tmp[0][0], tmp[0][1], spot)
        #     if tmp[2] == 1:
        #         for t in self.targets:
        #             if not t.flag:
        #                 self.aStar(t, t.destination)
        #     elif tmp[2] == 0:
        #         for t in self.targets:
        #             if not t.flag:
        #                 self.dijkstra(t, t.destination)
        # elif len(self.command_list) > 0 and len(self.command_list[0]) == 0:
        #     self.command_list.pop(0)

    def check_grid(self, tpl):  # Mapteki engelleri tespit eden kod
        for a in self.AGVs:
            if a.get_pos() == tpl:
                Tk().wm_withdraw()
                messagebox.showinfo("Wrong Place", "There is a robot ")
                return False
        for t in self.targets:
            if t.get_pos() == tpl:
                Tk().wm_withdraw()
                messagebox.showinfo("Wrong Place", "There is a target ")
                return False
        for o in self.obstacle:
            if o.get_pos() == tpl:
                Tk().wm_withdraw()
                messagebox.showinfo("Wrong Place", "There is an obstacle ")
                return False
        return True

    def check_grid2(self, tpl):  # Mapteki engelleri tespit eden kod
        for t in self.targets:
            if t.get_pos() == tpl:
                Tk().wm_withdraw()
                messagebox.showinfo("Wrong Place", "There is a target ")
                return False
        for o in self.obstacle:
            if o.get_pos() == tpl:
                Tk().wm_withdraw()
                messagebox.showinfo("Wrong Place", "There is an obstacle ")
                return False
        return True

    def take_command(self):  # görev inputunu alan kod
        command = self.InputBox.take_input()
        cmd = command.split()
        if self.check_grid(cmd):
            tmp = self.check_syntax(command)
            if tmp:
                for c in tmp:
                    spot = self.grid[c[1][0]][c[1][1]]
                    self.createTarget(c[0][0], c[0][1], spot)
                # self.command_list.append(tmp)

    def take_agv(self):  # Robot inputunu alan kod
        command = self.InputBoxAgv.take_input()
        if self.check_input(command):
            cmd = self.check_input(command)
            self.create_agv(int(cmd[0]), int(cmd[1]))

    def delete_obstacle(self, row, col):
        for o in self.obstacle:
            if o.row == row and o.col == col:
                self.obstacle.remove(o)

    def print_obstacle(self):
        for o in self.obstacle:
            if o.row in range (0, 5) and o.col in range (0, 5):
                print(str(o.row) + " " + str(o.col))
        print("-------------------------")

    def is_movable(self, pos):
        for agv in self.AGVs:
            if pos == agv.get_pos():
                return agv
        for o in self.obstacle:
            if pos == o.get_pos():
                return o
        return False

    def force_move(self, spot):
        if spot.y > 0 and not self.grid[spot.x][spot.y - 1].is_barrier() and not self.is_movable(
                (spot.x, spot.y + -1)):  # UP
            spot.set_pos((spot.x, spot.y + -1))
        elif spot.y < self.rows - 1 and not self.grid[spot.x][spot.y + 1].is_barrier() and not self.is_movable(
                (spot.x, spot.y + 1)):  # DOWN
            spot.set_pos((spot.x, spot.y + 1))
        elif spot.x < self.rows - 1 and not self.grid[spot.x + 1][spot.y].is_barrier() and not self.is_movable(
                (spot.x + 1, spot.y)):  # RIGHT
            spot.set_pos((spot.x + 1, spot.y))
        elif spot.x > 0 and not self.grid[spot.x - 1][spot.y].is_barrier() and not self.is_movable(
                (spot.x - 1, spot.y)):  # LEFT
            spot.set_pos((spot.x - 1, spot.y))

    def find_agv(self, pos):
        i = 0
        for a in self.AGVs:
            if a.get_pos() == pos:
                return i
            i += 1
        return False

    def handle_event(self, event):
        self.InputBox.handle_event(event)
        self.InputBoxAgv.handle_event(event)
        self.button2.check_event(event)
        self.button.check_event(event)

    def make_grid(self):
        self.grid = []
        gap = self.width // self.rows
        for i in range(self.rows):
            self.grid.append([])
            for j in range(self.rows):
                spot = Spot(i, j, gap, self.rows, 0)
                self.grid[i].append(spot)
        return self.grid

    def make_aGrid(self):
        self.aGrid = []
        for x in range(self.rows):
            self.aGrid.append([])
            for y in range(self.rows):
                spot = Spot(x, y, 10, self.rows, 0)
                self.aGrid[x].append(spot)
        return self.aGrid

    def make_aGrid2(self):
        self.aGrid2 = []
        for x in range(self.rows):
            self.aGrid2.append([])
            for y in range(self.rows):
                spot = Spot(x, y, 10, self.rows, 0)
                self.aGrid2[x].append(spot)
        return self.aGrid2

    def make_dGrid(self):
        self.dGrid = []
        for x in range(self.rows):
            self.dGrid.append([])
            for y in range(self.rows):
                spot = Spot(x, y, 10, self.rows, 0)
                self.dGrid[x].append(spot)
        return self.dGrid

    def make_dGrid2(self):
        self.dGrid2 = []
        for x in range(self.rows):
            self.dGrid2.append([])
            for y in range(self.rows):
                spot = Spot(x, y, 10, self.rows, 0)
                self.dGrid2[x].append(spot)
        return self.dGrid2

    def get_grid(self):
        return self.grid

    def update_grid(self):
        for x in range(self.rows):
            for y in range(self.rows):
                spot = self.grid[x][y]
                spot.weight = sys.maxsize
                spot.visited = False
                spot.prev = None

    def display_grid(self):
        for x in range(self.rows):
            for y in range(self.rows):
                spot = self.grid[x][y]
                print(str(spot.x) + " " + str(spot.y) + " " + str(spot.color) + " " + str(spot.get_difficulty()))
        print("*******************************************")

    def create_agv(self, x, y):  # Agv clasından obje üretip listesine atar
        vehicle = Agv(x, y, len(self.AGVs) + 1)
        self.AGVs.append(vehicle)

    def createTarget(self, x, y, dest):  # Target clasından obje üretip listesine atar
        target = Target(x, y, len(self.targets) + 1, dest)
        self.targets.append(target)
        return target

    def create_obs(self, x, y):
        for o in self.obstacle:
            if o.row == x and o.col == y:
                return
        spotObs = self.get_grid()[x][y]
        spotObs.make_barrier()
        self.obstacle.append(spotObs)

    def create_medium(self, x, y):
        spotObs = self.get_grid()[x][y]
        spotObs.make_medium()
        self.medium.append(spotObs)

    def create_hard(self, x, y):
        spotObs = self.get_grid()[x][y]
        spotObs.make_hard()
        self.hard.append(spotObs)

    def updateNeighbors(self):
        for row in self.get_grid():
            for spot in row:
                spot.update_neighbors(self.get_grid())

    def update_neighbors(self):
        for r in self.grid:
            for spot in r:
                spot.neighbors = []
                if spot.row < spot.total_rows - 1 and not self.grid[spot.row + 1][spot.col].is_barrier():  # DOWN
                    spot.neighbors.append(self.grid[spot.row + 1][spot.col])

                if spot.row > 0 and not self.grid[spot.row - 1][spot.col].is_barrier():  # UP
                    spot.neighbors.append(self.grid[spot.row - 1][spot.col])

                if spot.col < spot.total_rows - 1 and not self.grid[spot.row][spot.col + 1].is_barrier():  # RIGHT
                    spot.neighbors.append(self.grid[spot.row][spot.col + 1])

                if spot.col > 0 and not self.grid[spot.row][spot.col - 1].is_barrier():  # LEFT
                    spot.neighbors.append(self.grid[spot.row][spot.col - 1])

    def algorithm(self, start, end):  # Verilen iki noktanın arasındaki en ksıa yolu A* algoritması ile bulan kod
        self.updateNeighbors()
        count = 0
        spotAgv = self.get_grid()[start.get_pos()[0]][start.get_pos()[1]]
        spotTarget = self.get_grid()[end.get_pos()[0]][end.get_pos()[1]]
        open_set = PriorityQueue()
        open_set.put((0, count, spotAgv))
        came_from = {}
        g_score = {spot: float("inf") for row in self.grid for spot in row}
        g_score[spotAgv] = 0
        f_score = {spot: float("inf") for row in self.grid for spot in row}
        f_score[spotAgv] = self.h(spotAgv.get_pos(), spotTarget.get_pos())
        path = []

        open_set_hash = {spotAgv}

        while not open_set.empty():
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()

            current = open_set.get()[2]
            open_set_hash.remove(current)

            if current == spotTarget:
                if self.mod == 1:
                    self.aGrid[spotTarget.row][spotTarget.col].make_end()
                elif self.mod == 2:
                    self.aGrid2[spotTarget.row][spotTarget.col].make_end()
                return self.reconstruct_path(came_from, spotTarget, path)

            for neighbor in current.neighbors:
                temp_g_score = g_score[current] + neighbor.get_difficulty()
                if temp_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = temp_g_score
                    f_score[neighbor] = temp_g_score + self.h(neighbor.get_pos(), spotTarget.get_pos())
                    if neighbor not in open_set_hash:
                        count += 1
                        open_set.put((f_score[neighbor], count, neighbor))
                        open_set_hash.add(neighbor)
                        if self.mod == 1:
                            self.aGrid[neighbor.row][neighbor.col].make_closed()
                        elif self.mod == 2:
                            self.aGrid2[neighbor.row][neighbor.col].make_closed()
            if current != start:
                if self.mod == 1:
                    self.aGrid[current.row][current.col].make_open()
                elif self.mod == 2:
                    self.aGrid2[current.row][current.col].make_open()
        return []

    def aStar(self, target,
              goal):  # Verilen iki noktaya en kısa yoldan gidecek robotun seçilmesi ve pathinin ayarlanması (A*)
        self.mod = 2
        result = [sys.maxsize] * len(self.AGVs)
        path = [None] * len(self.AGVs)
        path2 = self.algorithm(target, goal)
        self.dijkstra_algorithm(target, goal)
        self.mod = 0
        i = 0
        for agv in self.AGVs:
            if agv.get_target() is not None:
                result[i] = sys.maxsize
            else:
                path[i] = self.algorithm(agv, target)
                if len(path[i]) == 0:
                    result[i] = sys.maxsize
                else:
                    result[i] = len(path[i])
            i += 1

        if 0 < min(result) < sys.maxsize:
            chosen = result.index(min(result))
            if path2 != [] and path[chosen] != []:
                self.mod = 1
                self.algorithm(self.AGVs[chosen], target)
                self.dijkstra_algorithm(self.AGVs[chosen], target)
                self.AGVs[chosen].set_path(path[chosen])
                self.AGVs[chosen].set_secondPath(path2)
                self.AGVs[chosen].set_target(target)
                self.AGVs[chosen].flag = 1
                target.flag = 1
                self.mod = 2
                return True
        return False

    def h(self, p1, p2):  # Tahmini mesafeyi dönderen kod
        x1, y1 = p1
        x2, y2 = p2
        return 1.01 * abs(x1 - x2) + abs(y1 - y2)

    def reconstruct_path(self, came_from, current, path):  # Pathi dönderen kod
        path.append(current.get_pos())
        # self.draw()
        while current in came_from:
            current = came_from[current]
            if self.mod == 1:
                self.aGrid[current.row][current.col].color = PURPLE
            elif self.mod == 2:
                self.aGrid2[current.row][current.col].color = PURPLE
            path.append(current.get_pos())
        path.remove(current.get_pos())
        if self.mod == 1:
            self.aGrid[current.row][current.col].color = ORANGE
        elif self.mod == 2:
            self.aGrid2[current.row][current.col].color = ORANGE
        return path

    def draw_grid(self, win, rows, width):  # kafesli yapıyı ekranda gösteren kod
        gap = width // rows
        sx = top_left_x
        sy = top_left_y
        for i in range(rows):
            pygame.draw.line(win, (128, 128, 128), (sy, i * gap + sx), (width + sy, i * gap + sx))
            for j in range(rows):
                pygame.draw.line(win, (128, 128, 128), (j * gap + sy, sx), (j * gap + sy, width + sx))

    def draw_aGrid(self, win, rows):
        width = 250
        gap = width // rows
        sx = top_left_x + 75
        sy = 70
        for i in range(rows):
            pygame.draw.line(win, (128, 128, 128), (sy, i * gap + sx), (width + sy, i * gap + sx))
            for j in range(rows):
                pygame.draw.line(win, (128, 128, 128), (j * gap + sy, sx), (j * gap + sy, width + sx))

    def draw_aGrid2(self, win, rows):
        width = 250
        gap = width // rows
        sx = top_left_x + 350
        sy = 70
        for i in range(rows):
            pygame.draw.line(win, (128, 128, 128), (sy, i * gap + sx), (width + sy, i * gap + sx))
            for j in range(rows):
                pygame.draw.line(win, (128, 128, 128), (j * gap + sy, sx), (j * gap + sy, width + sx))

    def draw_dGrid(self, win, rows):
        width = 250
        gap = width // rows
        sx = top_left_x + 75
        sy = 70 + top_left_y + 500
        for i in range(rows):
            pygame.draw.line(win, (128, 128, 128), (sy, i * gap + sx), (width + sy, i * gap + sx))
            for j in range(rows):
                pygame.draw.line(win, (128, 128, 128), (j * gap + sy, sx), (j * gap + sy, width + sx))

    def draw_dGrid2(self, win, rows):
        width = 250
        gap = width // rows
        sx = top_left_x + 350
        sy = 70 + top_left_y + 500
        for i in range(rows):
            pygame.draw.line(win, (128, 128, 128), (sy, i * gap + sx), (width + sy, i * gap + sx))
            for j in range(rows):
                pygame.draw.line(win, (128, 128, 128), (j * gap + sy, sx), (j * gap + sy, width + sx))

    def drawAgv(self):  # Robotları ekranda gösteren kod
        for v in self.AGVs:
            v.draw(self.win)
        for t in self.targets:
            t.draw(self.win)

    def draw_path(self, agv):  # Pathi çizdiriyorum
        for x, y in agv.get_path()[1:]:
            spotAgv = self.get_grid()[x][y]
            spotAgv.make_path()
        for x, y in agv.get_secondPath()[1:]:
            spotAgv = self.get_grid()[x][y]
            spotAgv.make_path()

    def draw(self):  # Görsel öğeleri ekrana bastıran kod
        self.win.fill((200, 200, 200))
        for row in self.grid:
            for spot in row:
                # spot.reset()
                spot.draw(self.win)
        for row in self.aGrid:
            for spot in row:
                spot.drawA(self.win)
        for row in self.dGrid:
            for spot in row:
                spot.drawD(self.win)
        for row in self.aGrid2:
            for spot in row:
                spot.drawA2(self.win)
        for row in self.dGrid2:
            for spot in row:
                spot.drawD2(self.win)

        self.win.blit(self.label, (70, 169))
        self.win.blit(self.label2, (960, 169))
        for i in range(0, 25):
            self.win.blit(self.myfont.render(str(i), 1, (0, 0, 0)), (390 + (i * 20), 95))
        for i in range(0, 25):
            if i < 10:
                self.win.blit(self.myfont.render(str(i), 1, (0, 0, 0)), (380, 110 + (i * 20)))
            else:
                self.win.blit(self.myfont.render(str(i), 1, (0, 0, 0)), (372, 110 + (i * 20)))

        self.draw_grid(self.win, self.rows, self.width)
        self.draw_aGrid(self.win, self.rows)
        self.draw_aGrid2(self.win, self.rows)
        self.draw_dGrid(self.win, self.rows)
        self.draw_dGrid2(self.win, self.rows)
        self.drawAgv()
        self.button.update(self.win)
        self.button2.update(self.win)
        self.InputBox.draw(self.win)
        self.InputBoxAgv.draw(self.win)
        pygame.draw.rect(self.win, GREY, (450, (WIDTH - 90), 20, 20))
        pygame.draw.rect(self.win, GREY2, (420, (WIDTH - 90), 20, 20))
        pygame.draw.rect(self.win, BLACK, (480, (WIDTH - 90), 20, 20))
        pygame.display.update()

    def update(self):  # Robotların hareketini sağladığımız yer
        self.do_command()
        # self.print_obstacle()
        for v in self.AGVs:
            if len(v.firstPath) > 0:  # Hedefe giderken
                cmd = v.firstPath[-1]
                if self.is_movable(cmd):  # bir sonraki gideceği yere gidemiyorsa
                    if v.wait == 0:
                        v.wait = 1
                        continue
                    elif v.wait == 1:
                        if self.is_robot(cmd):  # önündeki engel bir robotsa
                            if v.idNo > self.is_robot(cmd).idNo:
                                continue
                            self.grid[cmd[0]][cmd[1]].make_barrier()
                            # Robotun gideceği yerni resetlenmesi
                            self.reset_robot(v)
                            v.target.flag = 0
                            v.target = None
                            self.duplicate()
                            self.do_command()
                            self.grid[cmd[0]][cmd[1]].reset()
                            v.wait = 0
                        else: # önündeki engel bir bariyerse
                            self.reset_robot(v)
                            v.target.flag = 0
                            v.target = None
                            self.duplicate()
                            self.do_command()
                            v.wait = 0
                        continue
                else:
                    v.set_pos(cmd)
                    v.firstPath.pop()
                if len(v.firstPath) == 0: # Hedefi alır listeden siler hedef robotla bir bütün olur
                    if v.get_target() is not None:
                        v.get_target().set_flag(1)
                        self.targets.remove(v.get_target())
            elif len(v.secondPath) > 0: #ikincil hedefe giderken
                cmd = v.secondPath[-1]
                if self.is_movable(cmd):  # bir sonraki gideceği yere gidemiyorsa
                    self.mod = 0
                    if not self.algorithm(v, v.target.destination):
                        continue
                    self.mod = 2
                    if v.wait == 0: #1 sn bekle
                        v.wait = 1
                        continue
                    elif v.wait == 1: #bekledikten sonra
                        if self.is_robot(cmd): #önündeki engel robotsa
                            if len(v.secondPath) == 1:
                                self.duplicate()
                                v.secondPath = self.algorithm(v, v.target.destination)
                                self.dijkstra_algorithm(v, v.target.destination)
                                v.wait = 0
                            else:
                                if v.idNo > self.is_robot(cmd).idNo:
                                    continue
                                self.grid[cmd[0]][cmd[1]].make_barrier()
                                self.duplicate()
                                v.secondPath = self.algorithm(v, v.target.destination)
                                self.dijkstra_algorithm(v, v.target.destination)
                                self.grid[cmd[0]][cmd[1]].reset()
                                self.delete_obstacle(cmd[0], cmd[1])
                                v.wait = 0
                        else: #engel bariyer ise
                            self.duplicate()
                            v.secondPath = self.algorithm(v, v.target.destination)
                            self.dijkstra_algorithm(v, v.target.destination)
                            v.wait = 0
                        continue
                else:
                    v.set_pos(cmd)
                    v.secondPath.pop()
                if len(v.secondPath) == 0:
                    v.set_target(None)
                    v.flag = 0
        # for v in self.AGVs:
        #     if len(v.firstPath) > 0:
        #         cmd = v.firstPath.pop()
        #         if self.is_movable(cmd):
        #             if v.wait == 0:
        #                 v.wait = 1
        #                 v.firstPath.append(cmd)
        #                 continue
        #             if v.wait == 1:
        #                 if not self.grid[cmd[0]][cmd[1]].is_barrier():
        #                     self.grid[cmd[0]][cmd[1]].make_barrier()
        #                     target = self.grid[v.firstPath[0][0]][v.firstPath[0][1]]
        #                     v.firstPath = []
        #                     v.secondPath = []
        #                     self.duplicate()
        #                     self.aStar(v.target, v.target.destination)
        #                     self.grid[cmd[0]][cmd[1]].reset()
        #                     v.wait = 0
        #                 else:
        #                     # target = self.grid[v.firstPath[0][0]][v.firstPath[0][1]]
        #                     v.firstPath = []
        #                     v.secondPath = []
        #                     v.flag = 0
        #                     v.target.flag = 0
        #                     v.target = None
        #                     self.duplicate()
        #                     # self.aStar(self.targets[0], self.targets[0].destination)
        #                     self.do_command()
        #                     v.wait = 0
        #                 continue
        #         v.set_pos(cmd)
        #         if len(v.firstPath) == 0:
        #             if v.get_target() is not None:
        #                 v.get_target().set_flag(1)
        #                 self.targets.remove(v.get_target())
        #     elif len(v.secondPath) > 0:
        #         cmd = v.secondPath.pop()
        #         if self.is_movable(cmd):
        #             if v.wait == 0:
        #                 v.wait = 1
        #                 v.secondPath.append(cmd)
        #                 continue
        #             if v.wait == 1:
        #                 if len(v.secondPath) > 0:
        #                     if self.algorithm(v, self.grid[v.secondPath[0][0]][v.secondPath[0][1]]) == []:
        #                         v.secondPath.append(cmd)
        #                         print("offf")
        #                         continue
        #                 if self.is_movable(cmd) and len(v.secondPath) == 0:
        #                     self.force_move(self.AGVs[self.find_agv(cmd)])
        #                 else:
        #                     :if not self.grid[cmd[0]][cmd[1]].is_barrier() and not self.is_movable(cmd)
        #                         print("if")
        #                         self.grid[cmd[0]][cmd[1]].make_barrier()
        #                         target = self.grid[v.secondPath[0][0]][v.secondPath[0][1]]
        #                         self.duplicate()
        #                         v.secondPath = self.algorithm(v, target)
        #                         self.dijkstra_algorithm(v, target)
        #                         self.grid[cmd[0]][cmd[1]].reset()
        #                         v.wait = 0
        #                     else:
        #                         print("else")
        #                         target = self.grid[v.secondPath[0][0]][v.secondPath[0][1]]
        #                         self.duplicate()
        #                         path = self.algorithm(v, target)
        #                         v.secondPath = path
        #                         self.dijkstra_algorithm(v, target)
        #                         v.wait = 0
        #                     continue
        #         v.set_pos(cmd)
        #         if len(v.secondPath) == 0:
        #             v.set_target(None)
        #             v.flag = 0

    def get_clicked_pos(self, pos):  # Tıkladığımız yerin griddeki hangi gözde olduğunun dönderen kod
        gap = 20
        y, x = pos
        row = (y - top_left_y) // gap
        col = (x - top_left_x) // gap
        return row, col

    def dijkstra_algorithm(self, start,
                           end):  # Verilen iki noktanın arasındaki en ksıa yolu dijkstra algoritması ile bulan kod
        self.update_grid()
        self.updateNeighbors()
        spotAgv = self.get_grid()[start.get_pos()[0]][start.get_pos()[1]]
        spotTarget = self.get_grid()[end.get_pos()[0]][end.get_pos()[1]]
        spotAgv.weight = 0
        # self.display_grid()
        queue, visited = deque(), []
        path = []
        queue.append(spotAgv)
        spotAgv.visited = True

        while len(queue) > 0:
            current = queue.popleft()
            for i in current.neighbors:
                if not i.is_barrier():
                    i.visited = True
                    if self.mod == 1:
                        self.dGrid[i.row][i.col].color = GREEN
                    elif self.mod == 2:
                        self.dGrid2[i.row][i.col].color = GREEN
                    if i.weight > current.weight + i.get_difficulty():
                        i.prev = current
                        i.weight = current.weight + i.get_difficulty()
                        queue.append(i)
        if spotTarget.weight > 9999:
            print("There is no way")
        else:
            temp = spotTarget
            path.append(temp.get_pos())
            while temp.prev.prev:
                if self.mod == 1:
                    self.dGrid[temp.prev.row][temp.prev.col].color = PURPLE
                elif self.mod == 2:
                    self.dGrid2[temp.prev.row][temp.prev.col].color = PURPLE
                path.append(temp.prev.get_pos())
                temp = temp.prev
            if self.mod == 1:
                self.dGrid[spotAgv.row][spotAgv.col].color = ORANGE
                self.dGrid[spotTarget.row][spotTarget.col].color = TURQUOISE
            elif self.mod == 2:
                self.dGrid2[spotAgv.row][spotAgv.col].color = ORANGE
                self.dGrid2[spotTarget.row][spotTarget.col].color = TURQUOISE
            return path

    def dijkstra(self, target,
                 goal):  # Verilen iki noktaya en kısa yoldan gidecek robotun seçilmesi ve pathinin ayarlanması
        result = [None] * len(self.AGVs)
        path = [None] * len(self.AGVs)
        path2 = self.dijkstra_algorithm(target, goal)
        i = 0
        for agv in self.AGVs:
            if agv.get_target() is not None:
                result[i] = 99999
            else:
                path[i] = self.dijkstra_algorithm(agv, target)
                result[i] = len(path[i])
            i += 1
        chosen = result.index(min(result))
        self.AGVs[chosen].set_path(path[chosen])
        self.AGVs[chosen].set_secondPath(path2)
        self.AGVs[chosen].set_target(target)
        self.AGVs[chosen].flag = 1
        target.flag = 1
