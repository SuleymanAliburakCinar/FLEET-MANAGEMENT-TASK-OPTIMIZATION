import pygame

TURQUOISE = (64, 224, 208)


class Target:  # Hedef Clasımız
    def __init__(self, x, y, idNo, destination):
        self.x = x
        self.y = y
        self.idNo = idNo
        self.flag = 0
        self.destination = destination
        self.color = TURQUOISE

    def get_pos(self):
        return self.x, self.y

    def draw(self, win):
        pygame.draw.rect(win, self.color, ((self.x * 20) + 390, (self.y * 20) + 110, 20, 20))

    def set_pos(self, pos):
        self.x, self.y = pos

    def get_flag(self):
        return self.flag

    def set_flag(self, flag):
        self.flag = flag
