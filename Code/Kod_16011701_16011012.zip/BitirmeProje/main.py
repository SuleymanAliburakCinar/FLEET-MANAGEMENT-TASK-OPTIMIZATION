import time
import pygame as pygame

from Simulation import Simulation

WIDTH = 720
HEIGHT = 1280

top_left_x = (WIDTH - 500) // 2
top_left_y = (HEIGHT - 500) // 2

pygame.init()
WIN = pygame.display.set_mode((HEIGHT, WIDTH))
pygame.display.set_caption("Fleet Management Task Optimization")

RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 255, 0)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
PURPLE = (128, 0, 128)
ORANGE = (255, 165, 0)
GREY = (128, 128, 128)
TURQUOISE = (64, 224, 208)


def main(win, width):
    ROWS = 25
    simulation = Simulation(ROWS, 500)
    simulation.make_grid()

    clock = pygame.time.Clock()
    run = True

    barrier_select = True
    medium_select = False
    hard_select = False

    simulation.create_agv(3, 5)
    goal = simulation.get_grid()[4][10]
    goal2 = simulation.get_grid()[24][24]
    goal3 = simulation.get_grid()[3][2]
    simulation.create_obs(7, 6)
    simulation.create_obs(6, 6)
    simulation.create_obs(5, 6)
    simulation.create_obs(4, 6)
    simulation.create_obs(3, 6)
    simulation.create_obs(3, 7)
    simulation.create_obs(3, 8)
    simulation.create_obs(3, 9)
    simulation.create_obs(3, 10)
    simulation.create_obs(3, 11)
    simulation.create_obs(5, 8)
    simulation.create_obs(5, 9)
    simulation.create_obs(5, 10)
    simulation.create_obs(5, 11)
    simulation.create_obs(5, 12)
    simulation.create_obs(5, 13)
    simulation.create_obs(16, 2)
    simulation.create_obs(17, 2)
    simulation.create_obs(18, 2)
    simulation.create_obs(19, 2)
    simulation.create_obs(20, 2)
    simulation.create_obs(21, 2)
    simulation.create_obs(21, 3)
    simulation.create_obs(21, 4)
    simulation.create_obs(17, 11)
    simulation.create_obs(16, 12)
    simulation.create_obs(15, 13)
    simulation.create_obs(14, 14)
    simulation.create_obs(13, 14)
    simulation.create_obs(12, 14)
    simulation.create_obs(11, 14)
    simulation.create_obs(18, 11)
    simulation.create_obs(19, 11)
    simulation.create_obs(19, 10)
    simulation.create_obs(2, 20)
    simulation.create_obs(2, 21)
    simulation.create_obs(2, 22)
    simulation.create_obs(2, 22)
    simulation.create_obs(1, 22)
    simulation.create_obs(3, 21)
    simulation.create_obs(4, 22)
    simulation.create_obs(5, 23)
    simulation.create_obs(6, 24)
    simulation.create_obs(19, 19)
    simulation.create_obs(20, 20)
    simulation.create_obs(21, 21)
    simulation.create_obs(22, 22)

    simulation.make_aGrid()
    simulation.make_aGrid2()
    simulation.make_dGrid()
    simulation.make_dGrid2()

    while run:
        time_delta = clock.tick(60) / 1000.0
        simulation.draw()
        simulation.update()
        time.sleep(0.3)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            simulation.handle_event(event)
            mouse = pygame.mouse.get_pos()
            if 450 + 20 > mouse[0] > 450 and 630 + 20 > mouse[1] > 630 and pygame.mouse.get_pressed()[0]:  # Left Click
                medium_select = False
                barrier_select = False
                hard_select = True
            elif 420 + 20 > mouse[0] > 420 and 630 + 20 > mouse[1] > 630 and pygame.mouse.get_pressed()[0]:  # Left Click
                medium_select = True
                hard_select = False
                barrier_select = False
            elif 480 + 20 > mouse[0] > 480 and 630 + 20 > mouse[1] > 630 and pygame.mouse.get_pressed()[0]:
                medium_select = False
                hard_select = False
                barrier_select = True
            if 390 + 500 > mouse[0] > 390 and 110 + 500 > mouse[1] > 110 and pygame.mouse.get_pressed()[0]:  # LEFT
                pos = pygame.mouse.get_pos()
                row, col = simulation.get_clicked_pos(pos)
                if not simulation.is_robot((row, col)) and not simulation.is_target((row, col)):
                    if hard_select:
                        simulation.create_hard(row, col)
                    elif medium_select:
                        simulation.create_medium(row, col)
                    elif barrier_select:
                        simulation.create_obs(row, col)
            elif 390 + 500 > mouse[0] > 390 and 110 + 500 > mouse[1] > 110 and pygame.mouse.get_pressed()[2]:
                pos = pygame.mouse.get_pos()
                row, col = simulation.get_clicked_pos(pos)
                simulation.grid[row][col].reset()
                simulation.delete_obstacle(row, col)
            # print(simulation.AGVs[0].firstPath)
            # print(simulation.AGVs[0].flag)
            # for i in simulation.targets:
            #     print(i.flag)
            # print("**********************")
            # if 390 + 500 > mouse[0] > 390 and 110 + 500 > mouse[1] > 110 and pygame.mouse.get_pressed()[0]:
            # elif pygame.mouse.get_pressed()[2]:  # RIGHT
            #     pos = pyg ame.mouse.get_pos()
            #     row, col = simulation.get_clicked_pos(pos, ROWS, width)
            #     spot = simulation.grid[row][col]
            #     spot.reset()
            # simulation.button.check_event(event)
        pygame.display.update()
    pygame.quit()


main(WIN, WIDTH)
