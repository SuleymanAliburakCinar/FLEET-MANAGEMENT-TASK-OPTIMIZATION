list = [(5, 2), (10, 7), (9, 4)]
cmd = list.pop()
print(cmd)
list.append(cmd)
print(list)
for x in range(0, 6):
    if x % 2 == 0:
        continue
    print(x)