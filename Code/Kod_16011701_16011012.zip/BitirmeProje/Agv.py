import pygame

pygame.init()

ORANGE = (255, 165, 0)


class Agv:  # Robotlar Classımız
    def __init__(self, x, y, idNo):
        self.idNo = idNo
        self.x = x
        self.y = y
        self.color = ORANGE
        self.flag = 0
        self.wait = 0
        self.target = None
        self.firstPath = []
        self.secondPath = []

    def getNo(self):
        return self.idNo

    def get_pos(self):
        return self.x, self.y

    def set_pos(self, pos):
        self.x, self.y = pos

    def draw(self, win):
        pygame.draw.rect(win, self.color, ((self.x*20) + 390, (self.y*20) + 110, 20, 20))

    def update(self):
        if len(self.firstPath) > 0:
            cmd = self.firstPath.pop()
            self.set_pos(cmd)
            if len(self.firstPath) == 0:
                self.target.set_flag(1)
        elif len(self.secondPath) > 0:
            cmd = self.secondPath.pop()
            self.set_pos(cmd)

    def set_path(self, path):
        self.firstPath = path

    def get_path(self):
        return self.firstPath

    def set_secondPath(self, path):
        self.secondPath = path

    def get_secondPath(self):
        return self.secondPath

    def set_target(self, target):
        self.target = target

    def get_target(self):
        return self.target

    def is_loaded(self):
        if self.target is None:
            return 0
        else:
            return 1